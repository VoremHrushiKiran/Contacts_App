$(document).ready(function () {
  setTimeout(function () {
    $(".alert").alert("close");
  }, 5000);
});
